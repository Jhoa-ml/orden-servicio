<div class="dashboard-container">
  <div class="sidebar">
    <link rel="stylesheet" href="../assets/css/estilos.css">
    <h2>Administrador</h2>
    <ul>
      <li><a href="#">Inicio</a></li>
      <li><a href="#">Órdenes</a></li>
      <li><a href="#">Técnicos</a></li>
      <li><a href="#">Calificaciones</a></li>
      <li><a href="#">Cerrar sesión</a></li>
    </ul>
  </div>
  <div class="main-panel">
    <h1>Bienvenido, Administrador</h1>
    <p>Aquí puedes gestionar órdenes, ver el desempeño de técnicos y más.</p>
  </div>
</div>
